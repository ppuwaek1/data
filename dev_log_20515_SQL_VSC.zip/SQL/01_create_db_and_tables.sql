-- ==========================================================
-- [1단계] 데이터베이스 및 테이블 생성 + 초기 데이터 세팅
-- DB명은 반드시 학번(20515)으로 끝나야 함
-- ==========================================================
CREATE DATABASE IF NOT EXISTS dev_log_20515
  DEFAULT CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE dev_log_20515;

-- 1. 회원 관리 테이블 (users)
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    nickname VARCHAR(50) NOT NULL,
    phone_number VARCHAR(20) NOT NULL,
    entry_year INT NOT NULL,
    student_id VARCHAR(20) NOT NULL UNIQUE,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- 2. 핵심 데이터 테이블: 개발 일지 & 목표 관리 (dev_logs)
CREATE TABLE IF NOT EXISTS dev_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    final_goal VARCHAR(200) NOT NULL,          -- 최종 목표
    today_goal VARCHAR(200) NOT NULL,          -- 오늘의 목표
    title VARCHAR(150) NOT NULL,               -- 일지 제목
    content TEXT NOT NULL,                     -- 그날그날의 개발 일지 내용
    is_completed TINYINT(1) DEFAULT 0,         -- 오늘의 목표 달성 여부 (0: 진행중, 1: 달성완료)
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_dev_logs_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- 3. 초기 회원 3명 데이터 (백엔드 서버 실행 시 실제 bcrypt 해시값으로 자동 동기화됨)
INSERT IGNORE INTO users (id, email, password, nickname, phone_number, entry_year, student_id)
VALUES
(1, 'seungjun@devlog.net', '$2b$10$placeholderHashForSeungjun00000000000000000000000000', '이승준', '01012345678', 2025, '20515'),
(2, 'dongwook@devlog.net', '$2b$10$placeholderHashForDongwook00000000000000000000000000', '이동욱', '01087654321', 2025, '20516'),
(3, 'kyubin@devlog.net',   '$2b$10$placeholderHashForKyubin0000000000000000000000000000', '이규빈', '01011112222', 2025, '20517');

-- 4. 초기 개발 일지 샘플 데이터 3건
INSERT IGNORE INTO dev_logs (id, user_id, final_goal, today_goal, title, content, is_completed)
VALUES
(1, 1, '풀스택 웹 개발자 되기', 'React와 Express 회원가입/로그인 연동', '1일차: bcrypt 비밀번호 암호화 적용', 'Express 서버에서 bcrypt를 이용해 비밀번호를 안전하게 해싱하고 MySQL users 테이블에 연동했다.', 1),
(2, 2, '백엔드 시스템 엔지니어', 'MySQL 외래키 및 JOIN 쿼리 설계', '2일차: 회원-개발일지 1:N 관계 구축', 'users 테이블과 dev_logs 테이블을 user_id 외래키로 연결하고 INNER JOIN 및 LEFT JOIN 통계를 구현했다.', 1),
(3, 3, '프론트엔드 UI/UX 전문가', '개발 일지 목록 및 목표 체크 UI 구현', '3일차: 오늘의 목표 달성 체크 기능 추가', '사용자가 작성한 본인의 개발 일지만 수정 및 삭제할 수 있도록 권한 분기 처리를 완료했다.', 0);

SELECT * FROM users;
SELECT * FROM dev_logs;
