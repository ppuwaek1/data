-- ==========================================================
-- [2단계] SQL을 활용한 문제해결 (1번 ~ 9번 쿼리 모음)
-- MySQL Workbench에서 각 문제별로 드래그 후 실행(Ctrl+Shift+Enter) 가능
-- ==========================================================
USE dev_log_20515;
SET SQL_SAFE_UPDATES = 0;

-- [1번] 회원가입 쿼리문 (Create)
INSERT INTO users (email, password, nickname, phone_number, entry_year, student_id)
VALUES ('testuser@devlog.net', '$2b$10$T8M2V1bJ9p3A8j7fF4zK.hSxY/uta7L1234567890abcdef', '테스트회원', '01055556666', 2025, '20599');

-- [2번] 회원조회 쿼리문 (Read)
SELECT * FROM users;

-- [3번] 회원정보 수정 쿼리문 (Update)
UPDATE users
SET nickname = '이승준_수정', phone_number = '01099998888'
WHERE student_id = '20515';
SELECT * FROM users WHERE student_id = '20515';

-- (실습 후 원래 이름으로 복구)
UPDATE users SET nickname = '이승준', phone_number = '01012345678' WHERE student_id = '20515';

-- [4번] 회원탈퇴 쿼리문 (Delete)
DELETE FROM users
WHERE email = 'testuser@devlog.net';
SELECT * FROM users;

-- [5번] 핵심데이터 등록 쿼리문 (Create - 개발 일지 & 목표)
INSERT INTO dev_logs (user_id, final_goal, today_goal, title, content, is_completed)
VALUES (1, '풀스택 웹 개발자 되기', 'CRUD 전체 기능 점검', '수행평가 최종 점검 일지', '회원관리 CRUD와 핵심데이터 CRUD 및 JOIN 메뉴 2개 연동을 모두 완료했다.', 1);
SET @new_log_id = LAST_INSERT_ID();
SELECT * FROM dev_logs;

-- [6번] 핵심데이터 조회 쿼리문 (Read)
SELECT * FROM dev_logs ORDER BY created_at DESC;

-- [7번] 핵심데이터 수정 쿼리문 (Update - 본인 일지만 수정)
UPDATE dev_logs
SET today_goal = 'CRUD 및 예외 처리 최종 완료',
    content = '본인 작성 글만 수정/삭제 가능하도록 백엔드 검증 로직을 추가했다.',
    is_completed = 1
WHERE id = @new_log_id AND user_id = 1;
SELECT * FROM dev_logs WHERE id = @new_log_id;

-- [8번] 핵심데이터 삭제 쿼리문 (Delete - 본인 일지만 삭제)
DELETE FROM dev_logs
WHERE id = @new_log_id AND user_id = 1;
SELECT * FROM dev_logs;

-- [9번-1] 두 테이블 JOIN 결과 조회 1 (회원 정보 + 개발 일지 상세 통합)
SELECT
    u.student_id AS 학번,
    u.nickname AS 작성자,
    d.final_goal AS 최종목표,
    d.today_goal AS 오늘의목표,
    d.title AS 일지제목,
    d.content AS 일지내용,
    d.created_at AS 작성일시
FROM users u
INNER JOIN dev_logs d ON u.id = d.user_id
ORDER BY d.created_at DESC;

-- [9번-2] 두 테이블 JOIN 결과 조회 2 (회원별 작성 일지 수 및 목표 달성 통계)
SELECT
    u.student_id AS 학번,
    u.nickname AS 이름,
    u.email AS 이메일,
    COUNT(d.id) AS 작성일지수,
    SUM(CASE WHEN d.is_completed = 1 THEN 1 ELSE 0 END) AS 달성목표수,
    COALESCE(MAX(d.final_goal), '미설정') AS 최근최종목표
FROM users u
LEFT JOIN dev_logs d ON u.id = d.user_id
GROUP BY u.id, u.student_id, u.nickname, u.email;
