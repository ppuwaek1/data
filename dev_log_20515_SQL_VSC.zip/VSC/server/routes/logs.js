const express = require('express');
const { pool } = require('../db');
const { authenticate } = require('../middleware/auth');

const router = express.Router();

// [Read] 전체 개발 일지 목록 조회 (모든 사용자가 올린 목록 전체 출력 + 검색 지원)
router.get('/', async (req, res) => {
  const keyword = req.query.q ? `%${req.query.q}%` : null;
  try {
    let sql = `
      SELECT d.*, u.nickname, u.student_id, u.email
      FROM dev_logs d
      INNER JOIN users u ON d.user_id = u.id
    `;
    const params = [];

    if (keyword) {
      sql += ` WHERE d.title LIKE ? OR d.content LIKE ? OR d.final_goal LIKE ? OR d.today_goal LIKE ? OR u.nickname LIKE ?`;
      params.push(keyword, keyword, keyword, keyword, keyword);
    }

    sql += ` ORDER BY d.created_at DESC, d.id DESC`;

    const [rows] = await pool.query(sql, params);
    res.json(rows);
  } catch (err) {
    res.status(500).json({ message: '개발 일지 목록 조회 실패', error: err.message });
  }
});

// [Read] 특정 개발 일지 상세 조회
router.get('/:id', async (req, res) => {
  try {
    const [rows] = await pool.query(
      `SELECT d.*, u.nickname, u.student_id
       FROM dev_logs d
       INNER JOIN users u ON d.user_id = u.id
       WHERE d.id = ?`,
      [req.params.id]
    );
    if (rows.length === 0) {
      return res.status(404).json({ message: '해당 개발 일지를 찾을 수 없습니다.' });
    }
    res.json(rows[0]);
  } catch (err) {
    res.status(500).json({ message: '개발 일지 상세 조회 실패', error: err.message });
  }
});

// [Create] 개발 일지 & 목표 등록 (로그인된 상태에서만 작성 가능)
router.post('/', authenticate, async (req, res) => {
  const { final_goal, today_goal, title, content, is_completed } = req.body;
  const userId = req.user.id;

  if (!final_goal || !today_goal || !title || !content) {
    return res.status(400).json({ message: '최종 목표, 오늘의 목표, 제목, 내용을 모두 입력해주세요.' });
  }

  try {
    const [result] = await pool.query(
      'INSERT INTO dev_logs (user_id, final_goal, today_goal, title, content, is_completed) VALUES (?, ?, ?, ?, ?, ?)',
      [userId, final_goal, today_goal, title, content, is_completed ? 1 : 0]
    );
    res.status(201).json({
      message: '오늘의 개발 일지와 목표가 등록되었습니다.',
      logId: result.insertId,
    });
  } catch (err) {
    res.status(400).json({ message: '개발 일지 등록 실패', error: err.message });
  }
});

// [Update] 개발 일지 & 목표 수정 (본인이 작성한 데이터만 수정 가능)
router.put('/:id', authenticate, async (req, res) => {
  const logId = req.params.id;
  const userId = req.user.id;
  const { final_goal, today_goal, title, content, is_completed } = req.body;

  try {
    const [result] = await pool.query(
      `UPDATE dev_logs
       SET final_goal = ?, today_goal = ?, title = ?, content = ?, is_completed = ?
       WHERE id = ? AND user_id = ?`,
      [final_goal, today_goal, title, content, is_completed ? 1 : 0, logId, userId]
    );

    if (result.affectedRows === 0) {
      return res.status(403).json({ message: '본인이 작성한 개발 일지만 수정할 수 있습니다.' });
    }

    res.json({ message: '개발 일지가 수정되었습니다.' });
  } catch (err) {
    res.status(400).json({ message: '개발 일지 수정 실패', error: err.message });
  }
});

// [Update] 오늘의 목표 달성 상태 토글 (본인 작성 데이터만 가능)
router.patch('/:id/toggle', authenticate, async (req, res) => {
  const logId = req.params.id;
  const userId = req.user.id;

  try {
    const [result] = await pool.query(
      'UPDATE dev_logs SET is_completed = IF(is_completed = 1, 0, 1) WHERE id = ? AND user_id = ?',
      [logId, userId]
    );
    if (result.affectedRows === 0) {
      return res.status(403).json({ message: '본인이 작성한 목표만 변경할 수 있습니다.' });
    }
    res.json({ message: '오늘의 목표 달성 상태가 변경되었습니다.' });
  } catch (err) {
    res.status(500).json({ message: '상태 변경 실패', error: err.message });
  }
});

// [Delete] 개발 일지 삭제 (본인이 작성한 데이터만 삭제 가능)
router.delete('/:id', authenticate, async (req, res) => {
  const logId = req.params.id;
  const userId = req.user.id;

  try {
    const [result] = await pool.query(
      'DELETE FROM dev_logs WHERE id = ? AND user_id = ?',
      [logId, userId]
    );

    if (result.affectedRows === 0) {
      return res.status(403).json({ message: '본인이 작성한 개발 일지만 삭제할 수 있습니다.' });
    }

    res.json({ message: '개발 일지가 삭제되었습니다.' });
  } catch (err) {
    res.status(500).json({ message: '개발 일지 삭제 실패', error: err.message });
  }
});

module.exports = router;
