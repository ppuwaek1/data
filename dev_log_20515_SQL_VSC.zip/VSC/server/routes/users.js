const express = require('express');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const { pool } = require('../db');
const { authenticate, JWT_SECRET } = require('../middleware/auth');

const router = express.Router();

// [Create] 회원가입 (password는 bcrypt 암호화 필수)
router.post('/register', async (req, res) => {
  const { email, password, nickname, phone_number, entry_year, student_id } = req.body;

  if (!email || !password || !nickname || !phone_number || !student_id) {
    return res.status(400).json({ message: '모든 필수 항목을 입력해주세요.' });
  }

  try {
    const hashedPassword = await bcrypt.hash(password, 10);
    const [result] = await pool.query(
      'INSERT INTO users (email, password, nickname, phone_number, entry_year, student_id) VALUES (?, ?, ?, ?, ?, ?)',
      [email, hashedPassword, nickname, phone_number, Number(entry_year) || 2025, student_id]
    );
    res.status(201).json({
      message: '회원가입이 완료되었습니다.',
      userId: result.insertId,
    });
  } catch (err) {
    res.status(400).json({
      message: '회원가입 실패 (이미 사용 중인 이메일 또는 학번입니다).',
      error: err.message,
    });
  }
});

// [Read] 로그인
router.post('/login', async (req, res) => {
  const { email, password } = req.body;
  if (!email || !password) {
    return res.status(400).json({ message: '이메일과 비밀번호를 입력해주세요.' });
  }

  try {
    const [rows] = await pool.query('SELECT * FROM users WHERE email = ?', [email]);
    if (rows.length === 0) {
      return res.status(401).json({ message: '존재하지 않는 이메일입니다.' });
    }

    const user = rows[0];
    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) {
      return res.status(401).json({ message: '비밀번호가 일치하지 않습니다.' });
    }

    const token = jwt.sign(
      { id: user.id, email: user.email, nickname: user.nickname, student_id: user.student_id },
      JWT_SECRET,
      { expiresIn: '24h' }
    );

    const { password: _, ...safeUser } = user;
    res.json({
      message: `${user.nickname}님 환영합니다!`,
      token,
      user: safeUser,
    });
  } catch (err) {
    res.status(500).json({ message: '로그인 처리 중 오류가 발생했습니다.', error: err.message });
  }
});

// [Read] 전체 회원 목록 조회
router.get('/', async (req, res) => {
  try {
    const [rows] = await pool.query(
      'SELECT id, email, nickname, phone_number, entry_year, student_id, created_at FROM users ORDER BY id ASC'
    );
    res.json(rows);
  } catch (err) {
    res.status(500).json({ message: '회원 목록 조회 실패', error: err.message });
  }
});

// [Read] 마이페이지 프로필 조회
router.get('/:id', async (req, res) => {
  try {
    const [rows] = await pool.query(
      'SELECT id, email, nickname, phone_number, entry_year, student_id, created_at, updated_at FROM users WHERE id = ?',
      [req.params.id]
    );
    if (rows.length === 0) {
      return res.status(404).json({ message: '회원 정보를 찾을 수 없습니다.' });
    }
    res.json(rows[0]);
  } catch (err) {
    res.status(500).json({ message: '프로필 조회 실패', error: err.message });
  }
});

// [Update] 마이페이지 프로필 수정
router.put('/:id', authenticate, async (req, res) => {
  const targetId = Number(req.params.id);
  if (req.user.id !== targetId) {
    return res.status(403).json({ message: '본인의 프로필만 수정할 수 있습니다.' });
  }

  const { nickname, phone_number, entry_year, student_id, password } = req.body;
  try {
    if (password && password.trim() !== '') {
      const hashedPassword = await bcrypt.hash(password, 10);
      await pool.query(
        'UPDATE users SET nickname = ?, phone_number = ?, entry_year = ?, student_id = ?, password = ? WHERE id = ?',
        [nickname, phone_number, Number(entry_year) || 2025, student_id, hashedPassword, targetId]
      );
    } else {
      await pool.query(
        'UPDATE users SET nickname = ?, phone_number = ?, entry_year = ?, student_id = ? WHERE id = ?',
        [nickname, phone_number, Number(entry_year) || 2025, student_id, targetId]
      );
    }

    const [updated] = await pool.query(
      'SELECT id, email, nickname, phone_number, entry_year, student_id, created_at, updated_at FROM users WHERE id = ?',
      [targetId]
    );
    res.json({
      message: '프로필 정보가 수정되었습니다.',
      user: updated[0],
    });
  } catch (err) {
    res.status(400).json({ message: '프로필 수정 실패 (학번 중복 등을 확인하세요).', error: err.message });
  }
});

// [Delete] 회원 탈퇴 처리
router.delete('/:id', authenticate, async (req, res) => {
  const targetId = Number(req.params.id);
  if (req.user.id !== targetId) {
    return res.status(403).json({ message: '본인 계정만 탈퇴할 수 있습니다.' });
  }

  try {
    await pool.query('DELETE FROM users WHERE id = ?', [targetId]);
    res.json({ message: '회원 탈퇴가 완료되었습니다.' });
  } catch (err) {
    res.status(500).json({ message: '회원 탈퇴 처리 실패', error: err.message });
  }
});

module.exports = router;
