const express = require('express');
const { pool } = require('../db');

const router = express.Router();

// [JOIN 1] 회원(users) + 개발 일지(dev_logs) INNER JOIN 통합 조회
router.get('/detail', async (req, res) => {
  try {
    const [rows] = await pool.query(`
      SELECT
        d.id AS log_id,
        u.student_id,
        u.nickname,
        u.entry_year,
        u.email,
        d.final_goal,
        d.today_goal,
        d.title,
        d.content,
        d.is_completed,
        d.created_at
      FROM users u
      INNER JOIN dev_logs d ON u.id = d.user_id
      ORDER BY d.created_at DESC, d.id DESC
    `);
    res.json(rows);
  } catch (err) {
    res.status(500).json({ message: 'JOIN 1 조회 실패', error: err.message });
  }
});

// [JOIN 2] 회원(users) + 개발 일지(dev_logs) LEFT JOIN + GROUP BY 회원별 목표/일지 통계 조회
router.get('/stats', async (req, res) => {
  try {
    const [rows] = await pool.query(`
      SELECT
        u.id AS user_id,
        u.student_id,
        u.nickname,
        u.email,
        u.entry_year,
        COUNT(d.id) AS total_logs,
        COALESCE(SUM(CASE WHEN d.is_completed = 1 THEN 1 ELSE 0 END), 0) AS completed_goals,
        COALESCE(MAX(d.final_goal), '미설정') AS latest_final_goal,
        COALESCE(MAX(d.today_goal), '작성 내역 없음') AS latest_today_goal,
        MAX(d.created_at) AS last_logged_at
      FROM users u
      LEFT JOIN dev_logs d ON u.id = d.user_id
      GROUP BY u.id, u.student_id, u.nickname, u.email, u.entry_year
      ORDER BY total_logs DESC, u.student_id ASC
    `);
    res.json(rows);
  } catch (err) {
    res.status(500).json({ message: 'JOIN 2 조회 실패', error: err.message });
  }
});

module.exports = router;
