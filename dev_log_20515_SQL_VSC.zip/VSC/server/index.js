const express = require('express');
const cors = require('cors');
require('dotenv').config();

const { initDatabase } = require('./db');
const usersRouter = require('./routes/users');
const logsRouter = require('./routes/logs');
const joinsRouter = require('./routes/joins');

const app = express();
app.use(cors());
app.use(express.json());

app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', database: process.env.DB_NAME || 'dev_log_20515' });
});

app.use('/api/users', usersRouter);
app.use('/api/logs', logsRouter);
app.use('/api/joins', joinsRouter);

const PORT = process.env.PORT || 5000;

initDatabase().then(() => {
  app.listen(PORT, () => {
    console.log(`🚀 백엔드 서버 실행 중: http://localhost:${PORT}`);
  });
});
