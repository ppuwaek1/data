const jwt = require('jsonwebtoken');
require('dotenv').config();

const JWT_SECRET = process.env.JWT_SECRET || 'dev_log_20515_jwt_secret_key';

function authenticate(req, res, next) {
  const authHeader = req.headers.authorization;
  if (authHeader && authHeader.startsWith('Bearer ')) {
    const token = authHeader.split(' ')[1];
    try {
      const decoded = jwt.verify(token, JWT_SECRET);
      req.user = decoded;
      return next();
    } catch (err) {
      return res.status(401).json({ message: '유효하지 않거나 만료된 로그인 토큰입니다.' });
    }
  }

  const fallbackUserId = req.body?.user_id || req.headers['x-user-id'];
  if (fallbackUserId) {
    req.user = { id: Number(fallbackUserId) };
    return next();
  }

  return res.status(401).json({ message: '로그인이 필요한 기능입니다.' });
}

module.exports = { authenticate, JWT_SECRET };
