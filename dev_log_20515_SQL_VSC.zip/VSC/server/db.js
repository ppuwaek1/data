const mysql = require('mysql2/promise');
const bcrypt = require('bcrypt');
require('dotenv').config();

const DB_NAME = process.env.DB_NAME || 'dev_log_20515';

const pool = mysql.createPool({
  host: process.env.DB_HOST || 'localhost',
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASSWORD || 'root',
  database: DB_NAME,
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0,
});

async function initDatabase() {
  try {
    const rootConn = await mysql.createConnection({
      host: process.env.DB_HOST || 'localhost',
      user: process.env.DB_USER || 'root',
      password: process.env.DB_PASSWORD || 'root',
    });
    await rootConn.query(
      `CREATE DATABASE IF NOT EXISTS \`${DB_NAME}\` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci`
    );
    await rootConn.end();

    await pool.query(`
      CREATE TABLE IF NOT EXISTS users (
        id INT AUTO_INCREMENT PRIMARY KEY,
        email VARCHAR(100) NOT NULL UNIQUE,
        password VARCHAR(255) NOT NULL,
        nickname VARCHAR(50) NOT NULL,
        phone_number VARCHAR(20) NOT NULL,
        entry_year INT NOT NULL,
        student_id VARCHAR(20) NOT NULL UNIQUE,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
      )
    `);

    await pool.query(`
      CREATE TABLE IF NOT EXISTS dev_logs (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT NOT NULL,
        final_goal VARCHAR(200) NOT NULL,
        today_goal VARCHAR(200) NOT NULL,
        title VARCHAR(150) NOT NULL,
        content TEXT NOT NULL,
        is_completed TINYINT(1) DEFAULT 0,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        CONSTRAINT fk_dev_logs_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
      )
    `);

    const defaultUsers = [
      {
        email: 'seungjun@devlog.net',
        plainPw: 'qazwsx1029!',
        nickname: '이승준',
        phone_number: '01012345678',
        entry_year: 2025,
        student_id: '20515',
      },
      {
        email: 'dongwook@devlog.net',
        plainPw: 'qazwsx1029?',
        nickname: '이동욱',
        phone_number: '01087654321',
        entry_year: 2025,
        student_id: '20516',
      },
      {
        email: 'kyubin@devlog.net',
        plainPw: 'qazwsx1029.',
        nickname: '이규빈',
        phone_number: '01011112222',
        entry_year: 2025,
        student_id: '20517',
      },
    ];

    for (const u of defaultUsers) {
      const [rows] = await pool.query('SELECT id, password FROM users WHERE email = ?', [u.email]);
      if (rows.length === 0) {
        const hashed = await bcrypt.hash(u.plainPw, 10);
        await pool.query(
          'INSERT INTO users (email, password, nickname, phone_number, entry_year, student_id) VALUES (?, ?, ?, ?, ?, ?)',
          [u.email, hashed, u.nickname, u.phone_number, u.entry_year, u.student_id]
        );
      } else if (rows[0].password.includes('placeholderHash')) {
        const hashed = await bcrypt.hash(u.plainPw, 10);
        await pool.query('UPDATE users SET password = ? WHERE id = ?', [hashed, rows[0].id]);
      }
    }

    const [logCount] = await pool.query('SELECT COUNT(*) AS cnt FROM dev_logs');
    if (logCount[0].cnt === 0) {
      const [userRows] = await pool.query('SELECT id, email FROM users ORDER BY id ASC');
      const userMap = {};
      userRows.forEach((r) => (userMap[r.email] = r.id));

      if (userMap['seungjun@devlog.net']) {
        await pool.query(
          'INSERT INTO dev_logs (user_id, final_goal, today_goal, title, content, is_completed) VALUES (?, ?, ?, ?, ?, ?)',
          [
            userMap['seungjun@devlog.net'],
            '풀스택 웹 개발자 되기',
            'React와 Express 회원가입/로그인 연동',
            '1일차: bcrypt 비밀번호 암호화 적용',
            'Express 서버에서 bcrypt를 이용해 비밀번호를 안전하게 해싱하고 MySQL users 테이블에 연동했다.',
            1,
          ]
        );
      }
      if (userMap['dongwook@devlog.net']) {
        await pool.query(
          'INSERT INTO dev_logs (user_id, final_goal, today_goal, title, content, is_completed) VALUES (?, ?, ?, ?, ?, ?)',
          [
            userMap['dongwook@devlog.net'],
            '백엔드 시스템 엔지니어',
            'MySQL 외래키 및 JOIN 쿼리 설계',
            '2일차: 회원-개발일지 1:N 관계 구축',
            'users 테이블과 dev_logs 테이블을 user_id 외래키로 연결하고 INNER JOIN 및 LEFT JOIN 통계를 구현했다.',
            1,
          ]
        );
      }
      if (userMap['kyubin@devlog.net']) {
        await pool.query(
          'INSERT INTO dev_logs (user_id, final_goal, today_goal, title, content, is_completed) VALUES (?, ?, ?, ?, ?, ?)',
          [
            userMap['kyubin@devlog.net'],
            '프론트엔드 UI/UX 전문가',
            '개발 일지 목록 및 목표 체크 UI 구현',
            '3일차: 오늘의 목표 달성 체크 기능 추가',
            '사용자가 작성한 본인의 개발 일지만 수정 및 삭제할 수 있도록 권한 분기 처리를 완료했다.',
            0,
          ]
        );
      }
    }

    console.log(`✅ MySQL [${DB_NAME}] 데이터베이스 및 테이블 준비 완료`);
  } catch (err) {
    console.error('❌ MySQL 연결 오류 (server/.env의 DB_PASSWORD를 확인하세요):', err.message);
  }
}

module.exports = { pool, initDatabase };
