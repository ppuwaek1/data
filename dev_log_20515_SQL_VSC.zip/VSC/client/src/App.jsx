import { useState, useEffect } from 'react';

const API_BASE = 'http://localhost:5000/api';

function App() {
  const [user, setUser] = useState(null);
  const [token, setToken] = useState('');
  const [activeTab, setActiveTab] = useState('logs'); // logs | join1 | join2 | mypage | auth
  const [authMode, setAuthMode] = useState('login'); // login | register

  // 로그인 / 회원가입 폼 상태
  const [authForm, setAuthForm] = useState({
    email: '',
    password: '',
    nickname: '',
    phone_number: '',
    entry_year: 2025,
    student_id: '',
  });

  // 마이페이지 프로필 수정 상태
  const [profileForm, setProfileForm] = useState({
    nickname: '',
    phone_number: '',
    entry_year: 2025,
    student_id: '',
    password: '',
  });

  // 개발 일지 상태
  const [logs, setLogs] = useState([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [onlyMine, setOnlyMine] = useState(false);
  const [editingLogId, setEditingLogId] = useState(null);
  const [logForm, setLogForm] = useState({
    final_goal: '',
    today_goal: '',
    title: '',
    content: '',
    is_completed: false,
  });

  // JOIN 결과 2개 상태
  const [joinDetail, setJoinDetail] = useState([]);
  const [joinStats, setJoinStats] = useState([]);

  useEffect(() => {
    const savedUser = localStorage.getItem('devlog_user');
    const savedToken = localStorage.getItem('devlog_token');
    if (savedUser && savedToken) {
      const parsedUser = JSON.parse(savedUser);
      setUser(parsedUser);
      setToken(savedToken);
      setProfileForm({
        nickname: parsedUser.nickname,
        phone_number: parsedUser.phone_number,
        entry_year: parsedUser.entry_year,
        student_id: parsedUser.student_id,
        password: '',
      });
    }
    fetchLogs();
    fetchJoins();
  }, []);

  const authHeaders = () => ({
    'Content-Type': 'application/json',
    ...(token ? { Authorization: `Bearer ${token}` } : {}),
  });

  const fetchLogs = async (q = '') => {
    try {
      const url = q ? `${API_BASE}/logs?q=${encodeURIComponent(q)}` : `${API_BASE}/logs`;
      const res = await fetch(url);
      const data = await res.json();
      if (Array.isArray(data)) {
        setLogs(data);
      }
    } catch (err) {
      console.error('일지 불러오기 오류:', err);
    }
  };

  const fetchJoins = async () => {
    try {
      const [res1, res2] = await Promise.all([
        fetch(`${API_BASE}/joins/detail`),
        fetch(`${API_BASE}/joins/stats`),
      ]);
      const data1 = await res1.json();
      const data2 = await res2.json();
      if (Array.isArray(data1)) setJoinDetail(data1);
      if (Array.isArray(data2)) setJoinStats(data2);
    } catch (err) {
      console.error('JOIN 조회 오류:', err);
    }
  };

  // [회원관리 - Create] 회원가입
  const handleRegister = async (e) => {
    e.preventDefault();
    const res = await fetch(`${API_BASE}/users/register`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(authForm),
    });
    const data = await res.json();
    alert(data.message);
    if (res.ok) {
      setAuthMode('login');
      setAuthForm((prev) => ({ ...prev, password: '' }));
      fetchJoins();
    }
  };

  // [회원관리 - Read] 로그인
  const handleLogin = async (e) => {
    e.preventDefault();
    const res = await fetch(`${API_BASE}/users/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email: authForm.email, password: authForm.password }),
    });
    const data = await res.json();
    if (res.ok) {
      setUser(data.user);
      setToken(data.token);
      localStorage.setItem('devlog_user', JSON.stringify(data.user));
      localStorage.setItem('devlog_token', data.token);
      setProfileForm({
        nickname: data.user.nickname,
        phone_number: data.user.phone_number,
        entry_year: data.user.entry_year,
        student_id: data.user.student_id,
        password: '',
      });
      const myLatest = logs.find((item) => item.user_id === data.user.id);
      setLogForm({
        final_goal: myLatest ? myLatest.final_goal : '',
        today_goal: '',
        title: '',
        content: '',
        is_completed: false,
      });
      setActiveTab('logs');
    } else {
      alert(data.message);
    }
  };

  const handleLogout = () => {
    setUser(null);
    setToken('');
    setOnlyMine(false);
    localStorage.removeItem('devlog_user');
    localStorage.removeItem('devlog_token');
    setEditingLogId(null);
    setActiveTab('logs');
  };

  // [회원관리 - Update] 마이페이지 프로필 수정
  const handleUpdateProfile = async (e) => {
    e.preventDefault();
    const res = await fetch(`${API_BASE}/users/${user.id}`, {
      method: 'PUT',
      headers: authHeaders(),
      body: JSON.stringify({ ...profileForm, user_id: user.id }),
    });
    const data = await res.json();
    alert(data.message);
    if (res.ok) {
      setUser(data.user);
      localStorage.setItem('devlog_user', JSON.stringify(data.user));
      setProfileForm((prev) => ({ ...prev, password: '' }));
      fetchLogs(searchQuery);
      fetchJoins();
    }
  };

  // [회원관리 - Delete] 회원 탈퇴
  const handleDeleteAccount = async () => {
    if (!window.confirm('정말 탈퇴하시겠습니까? 작성한 모든 개발 일지도 함께 삭제됩니다.')) return;
    const res = await fetch(`${API_BASE}/users/${user.id}`, {
      method: 'DELETE',
      headers: authHeaders(),
      body: JSON.stringify({ user_id: user.id }),
    });
    const data = await res.json();
    alert(data.message);
    if (res.ok) {
      handleLogout();
      fetchLogs();
      fetchJoins();
    }
  };

  // [핵심데이터 - Create / Update] 개발 일지 등록 및 수정
  const handleLogSubmit = async (e) => {
    e.preventDefault();
    if (!user) return alert('로그인 후 작성할 수 있습니다.');

    const url = editingLogId ? `${API_BASE}/logs/${editingLogId}` : `${API_BASE}/logs`;
    const method = editingLogId ? 'PUT' : 'POST';

    const res = await fetch(url, {
      method,
      headers: authHeaders(),
      body: JSON.stringify({ ...logForm, user_id: user.id }),
    });
    const data = await res.json();
    alert(data.message);

    if (res.ok) {
      setEditingLogId(null);
      setLogForm({
        final_goal: logForm.final_goal,
        today_goal: '',
        title: '',
        content: '',
        is_completed: false,
      });
      fetchLogs(searchQuery);
      fetchJoins();
    }
  };

  const handleStartEdit = (log) => {
    setEditingLogId(log.id);
    setLogForm({
      final_goal: log.final_goal,
      today_goal: log.today_goal,
      title: log.title,
      content: log.content,
      is_completed: Boolean(log.is_completed),
    });
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleToggleGoal = async (logId) => {
    const res = await fetch(`${API_BASE}/logs/${logId}/toggle`, {
      method: 'PATCH',
      headers: authHeaders(),
      body: JSON.stringify({ user_id: user.id }),
    });
    if (res.ok) {
      fetchLogs(searchQuery);
      fetchJoins();
    }
  };

  // [핵심데이터 - Delete] 개발 일지 삭제
  const handleDeleteLog = async (logId) => {
    if (!window.confirm('이 개발 일지를 삭제하시겠습니까?')) return;
    const res = await fetch(`${API_BASE}/logs/${logId}`, {
      method: 'DELETE',
      headers: authHeaders(),
      body: JSON.stringify({ user_id: user.id }),
    });
    const data = await res.json();
    alert(data.message);
    if (res.ok) {
      fetchLogs(searchQuery);
      fetchJoins();
    }
  };

  const visibleLogs = onlyMine && user ? logs.filter((l) => l.user_id === user.id) : logs;

  return (
    <div className="container">
      {/* 상단 헤더 */}
      <header className="header">
        <div className="header-title">
          <h1>💻 개발 일지 & 목표 관리 (DevLog 20515)</h1>
          <p>최종 목표와 오늘의 목표를 세우고 매일의 개발 기록을 남기는 공간</p>
        </div>

        <div className="user-bar">
          {user ? (
            <>
              <span>
                <strong>{user.nickname}</strong> ({user.student_id})
              </span>
              <button className="btn btn-outline" onClick={handleLogout}>
                로그아웃
              </button>
            </>
          ) : (
            <button className="btn btn-primary" onClick={() => setActiveTab('auth')}>
              로그인 / 회원가입
            </button>
          )}
        </div>
      </header>

      {/* 네비게이션 탭 */}
      <nav className="nav-tabs">
        <button
          className={`tab-btn ${activeTab === 'logs' ? 'active' : ''}`}
          onClick={() => {
            setActiveTab('logs');
            fetchLogs(searchQuery);
          }}
        >
          📝 개발 일지 (전체목록 & 작성)
        </button>
        <button
          className={`tab-btn ${activeTab === 'join1' ? 'active' : ''}`}
          onClick={() => {
            setActiveTab('join1');
            fetchJoins();
          }}
        >
          🔗 JOIN 조회 1 (회원 + 일지 상세)
        </button>
        <button
          className={`tab-btn ${activeTab === 'join2' ? 'active' : ''}`}
          onClick={() => {
            setActiveTab('join2');
            fetchJoins();
          }}
        >
          📊 JOIN 조회 2 (회원별 목표/일지 통계)
        </button>
        {user && (
          <button
            className={`tab-btn ${activeTab === 'mypage' ? 'active' : ''}`}
            onClick={() => setActiveTab('mypage')}
          >
            👤 마이페이지 (정보수정 / 탈퇴)
          </button>
        )}
      </nav>

      {/* 1. 로그인 / 회원가입 */}
      {activeTab === 'auth' && !user && (
        <div className="card">
          <div className="btn-group" style={{ marginTop: 0, marginBottom: '16px' }}>
            <button
              className={`btn ${authMode === 'login' ? 'btn-primary' : 'btn-outline'}`}
              onClick={() => setAuthMode('login')}
            >
              로그인
            </button>
            <button
              className={`btn ${authMode === 'register' ? 'btn-primary' : 'btn-outline'}`}
              onClick={() => setAuthMode('register')}
            >
              회원가입
            </button>
          </div>

          {authMode === 'login' ? (
            <form onSubmit={handleLogin}>
              <div className="form-group">
                <label>이메일</label>
                <input
                  type="email"
                  required
                  placeholder="seungjun@devlog.net"
                  value={authForm.email}
                  onChange={(e) => setAuthForm({ ...authForm, email: e.target.value })}
                />
              </div>
              <div className="form-group">
                <label>비밀번호</label>
                <input
                  type="password"
                  required
                  placeholder="qazwsx1029!"
                  value={authForm.password}
                  onChange={(e) => setAuthForm({ ...authForm, password: e.target.value })}
                />
              </div>
              <button type="submit" className="btn btn-primary">
                로그인
              </button>
            </form>
          ) : (
            <form onSubmit={handleRegister}>
              <div className="grid-2">
                <div className="form-group">
                  <label>이메일 *</label>
                  <input
                    type="email"
                    required
                    placeholder="example@devlog.net"
                    value={authForm.email}
                    onChange={(e) => setAuthForm({ ...authForm, email: e.target.value })}
                  />
                </div>
                <div className="form-group">
                  <label>비밀번호 (bcrypt 암호화 저장) *</label>
                  <input
                    type="password"
                    required
                    placeholder="비밀번호 입력"
                    value={authForm.password}
                    onChange={(e) => setAuthForm({ ...authForm, password: e.target.value })}
                  />
                </div>
                <div className="form-group">
                  <label>이름 (닉네임) *</label>
                  <input
                    type="text"
                    required
                    placeholder="이승준"
                    value={authForm.nickname}
                    onChange={(e) => setAuthForm({ ...authForm, nickname: e.target.value })}
                  />
                </div>
                <div className="form-group">
                  <label>전화번호 *</label>
                  <input
                    type="text"
                    required
                    placeholder="01012345678"
                    value={authForm.phone_number}
                    onChange={(e) => setAuthForm({ ...authForm, phone_number: e.target.value })}
                  />
                </div>
                <div className="form-group">
                  <label>입학년도 *</label>
                  <input
                    type="number"
                    required
                    value={authForm.entry_year}
                    onChange={(e) => setAuthForm({ ...authForm, entry_year: e.target.value })}
                  />
                </div>
                <div className="form-group">
                  <label>학번 *</label>
                  <input
                    type="text"
                    required
                    placeholder="20515"
                    value={authForm.student_id}
                    onChange={(e) => setAuthForm({ ...authForm, student_id: e.target.value })}
                  />
                </div>
              </div>
              <button type="submit" className="btn btn-primary">
                회원가입 완료
              </button>
            </form>
          )}
        </div>
      )}

      {/* 2. 개발 일지 & 목표 관리 (핵심 데이터 CRUD) */}
      {activeTab === 'logs' && (
        <>
          {user ? (
            <div className="card">
              <h2>{editingLogId ? '✏️ 개발 일지 및 목표 수정' : '🎯 목표 설정 & 오늘의 개발 일지 작성'}</h2>
              <form onSubmit={handleLogSubmit}>
                <div className="grid-2">
                  <div className="form-group">
                    <label>🏆 최종 목표 (Final Goal)</label>
                    <input
                      type="text"
                      required
                      placeholder="예: 풀스택 웹 개발자 되기"
                      value={logForm.final_goal}
                      onChange={(e) => setLogForm({ ...logForm, final_goal: e.target.value })}
                    />
                  </div>
                  <div className="form-group">
                    <label>📌 오늘의 목표 (Today Goal)</label>
                    <input
                      type="text"
                      required
                      placeholder="예: React & MySQL CRUD 연동 완성"
                      value={logForm.today_goal}
                      onChange={(e) => setLogForm({ ...logForm, today_goal: e.target.value })}
                    />
                  </div>
                </div>

                <div className="form-group">
                  <label>일지 제목</label>
                  <input
                    type="text"
                    required
                    placeholder="오늘 개발한 핵심 주제를 입력하세요"
                    value={logForm.title}
                    onChange={(e) => setLogForm({ ...logForm, title: e.target.value })}
                  />
                </div>

                <div className="form-group">
                  <label>오늘의 개발 일지 내용</label>
                  <textarea
                    required
                    placeholder="오늘 구현한 기능, 발생한 에러와 해결 방법, 배운 점을 자유롭게 기록하세요."
                    value={logForm.content}
                    onChange={(e) => setLogForm({ ...logForm, content: e.target.value })}
                  />
                </div>

                <label className="checkbox-row">
                  <input
                    type="checkbox"
                    checked={logForm.is_completed}
                    onChange={(e) => setLogForm({ ...logForm, is_completed: e.target.checked })}
                  />
                  오늘의 목표 달성 완료 체크
                </label>

                <div className="btn-group">
                  <button type="submit" className="btn btn-primary">
                    {editingLogId ? '수정 내용 저장' : '개발 일지 등록'}
                  </button>
                  {editingLogId && (
                    <button
                      type="button"
                      className="btn btn-secondary"
                      onClick={() => {
                        setEditingLogId(null);
                        setLogForm({
                          final_goal: logForm.final_goal,
                          today_goal: '',
                          title: '',
                          content: '',
                          is_completed: false,
                        });
                      }}
                    >
                      취소
                    </button>
                  )}
                </div>
              </form>
            </div>
          ) : (
            <div className="notice-box">
              🔒 <strong>로그인</strong>하면 최종 목표와 오늘의 목표를 설정하고 개발 일지를 작성할 수 있습니다. (전체 일지 목록 조회는 비로그인 상태에서도 가능합니다)
            </div>
          )}

          {/* 검색 및 내 글 필터 바 */}
          <form
            className="toolbar"
            onSubmit={(e) => {
              e.preventDefault();
              fetchLogs(searchQuery);
            }}
          >
            <input
              type="text"
              placeholder="작성자, 목표, 제목, 내용으로 개발 일지 검색..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
            <button type="submit" className="btn btn-primary">
              검색
            </button>
            {searchQuery && (
              <button
                type="button"
                className="btn btn-outline"
                onClick={() => {
                  setSearchQuery('');
                  fetchLogs('');
                }}
              >
                초기화
              </button>
            )}
            {user && (
              <button
                type="button"
                className={`btn ${onlyMine ? 'btn-primary' : 'btn-outline'}`}
                onClick={() => setOnlyMine(!onlyMine)}
              >
                {onlyMine ? '전체 일지 보기' : '내 일지만 보기'}
              </button>
            )}
          </form>

          {/* 전체 사용자 개발 일지 목록 (Read) */}
          <h2 style={{ fontSize: '1.08rem', marginBottom: '12px' }}>
            📚 {onlyMine ? '내가 작성한 개발 일지' : '전체 사용자 개발 일지'} ({visibleLogs.length}건)
          </h2>

          {visibleLogs.length === 0 ? (
            <div className="card">표시할 개발 일지가 없습니다.</div>
          ) : (
            visibleLogs.map((log) => (
              <div className="card" key={log.id}>
                <div className="badges">
                  <span className="badge badge-final">🏆 최종 목표: {log.final_goal}</span>
                  <span className="badge badge-today">📌 오늘의 목표: {log.today_goal}</span>
                  <span className={`badge ${log.is_completed ? 'badge-done' : 'badge-doing'}`}>
                    {log.is_completed ? '✅ 목표 달성 완료' : '⏳ 목표 진행 중'}
                  </span>
                </div>

                <div className="log-title">{log.title}</div>
                <div className="log-meta">
                  작성자: <strong>{log.nickname}</strong> ({log.student_id}) · 작성일:{' '}
                  {new Date(log.created_at).toLocaleString('ko-KR')}
                </div>

                <div className="log-content">{log.content}</div>

                {/* 본인이 작성한 데이터만 수정/삭제 가능 */}
                {user && user.id === log.user_id && (
                  <div className="btn-group">
                    <button className="btn btn-outline" onClick={() => handleToggleGoal(log.id)}>
                      {log.is_completed ? '진행중으로 변경' : '목표 달성 체크'}
                    </button>
                    <button className="btn btn-outline" onClick={() => handleStartEdit(log)}>
                      수정
                    </button>
                    <button className="btn btn-danger" onClick={() => handleDeleteLog(log.id)}>
                      삭제
                    </button>
                  </div>
                )}
              </div>
            ))
          )}
        </>
      )}

      {/* 3. JOIN 결과 1 (INNER JOIN) */}
      {activeTab === 'join1' && (
        <div className="card">
          <h2>🔗 JOIN 결과 1: 회원(users) + 개발 일지(dev_logs) INNER JOIN 상세 조회</h2>
          <pre className="sql-preview">
{`SELECT u.student_id, u.nickname, u.entry_year, d.final_goal, d.today_goal, d.title, d.content, d.is_completed
FROM users u
INNER JOIN dev_logs d ON u.id = d.user_id
ORDER BY d.created_at DESC;`}
          </pre>
          <div className="table-wrap">
            <table>
              <thead>
                <tr>
                  <th>학번</th>
                  <th>작성자</th>
                  <th>입학년도</th>
                  <th>최종 목표</th>
                  <th>오늘의 목표</th>
                  <th>일지 제목 & 내용</th>
                  <th>달성여부</th>
                </tr>
              </thead>
              <tbody>
                {joinDetail.map((row) => (
                  <tr key={row.log_id}>
                    <td>{row.student_id}</td>
                    <td><strong>{row.nickname}</strong></td>
                    <td>{row.entry_year}</td>
                    <td>{row.final_goal}</td>
                    <td>{row.today_goal}</td>
                    <td>
                      <strong>{row.title}</strong>
                      <div style={{ color: '#4b5563', marginTop: '4px', fontSize: '0.84rem' }}>
                        {row.content}
                      </div>
                    </td>
                    <td>{row.is_completed ? '✅ 달성' : '⏳ 진행중'}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* 4. JOIN 결과 2 (LEFT JOIN + GROUP BY) */}
      {activeTab === 'join2' && (
        <div className="card">
          <h2>📊 JOIN 결과 2: 회원별 개발 일지 작성 및 목표 달성 통계 (LEFT JOIN + GROUP BY)</h2>
          <pre className="sql-preview">
{`SELECT u.student_id, u.nickname, u.email, COUNT(d.id) AS total_logs,
       SUM(CASE WHEN d.is_completed = 1 THEN 1 ELSE 0 END) AS completed_goals,
       MAX(d.final_goal) AS latest_final_goal
FROM users u
LEFT JOIN dev_logs d ON u.id = d.user_id
GROUP BY u.id, u.student_id, u.nickname, u.email;`}
          </pre>
          <div className="table-wrap">
            <table>
              <thead>
                <tr>
                  <th>학번</th>
                  <th>이름</th>
                  <th>이메일</th>
                  <th>작성 일지 수</th>
                  <th>달성한 목표 수</th>
                  <th>설정한 최종 목표</th>
                  <th>최근 오늘의 목표</th>
                </tr>
              </thead>
              <tbody>
                {joinStats.map((row) => (
                  <tr key={row.user_id}>
                    <td>{row.student_id}</td>
                    <td><strong>{row.nickname}</strong></td>
                    <td>{row.email}</td>
                    <td><strong>{row.total_logs}건</strong></td>
                    <td>{row.completed_goals}건</td>
                    <td>{row.latest_final_goal}</td>
                    <td>{row.latest_today_goal}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* 5. 마이페이지 (회원관리 Read, Update, Delete) */}
      {activeTab === 'mypage' && user && (
        <div className="card">
          <h2>👤 마이페이지 (내 프로필 조회 / 수정 / 회원 탈퇴)</h2>
          <p className="log-meta">가입 이메일: <strong>{user.email}</strong> (이메일은 변경 불가)</p>

          <form onSubmit={handleUpdateProfile}>
            <div className="grid-2">
              <div className="form-group">
                <label>이름 (닉네임)</label>
                <input
                  type="text"
                  required
                  value={profileForm.nickname}
                  onChange={(e) => setProfileForm({ ...profileForm, nickname: e.target.value })}
                />
              </div>
              <div className="form-group">
                <label>전화번호</label>
                <input
                  type="text"
                  required
                  value={profileForm.phone_number}
                  onChange={(e) => setProfileForm({ ...profileForm, phone_number: e.target.value })}
                />
              </div>
              <div className="form-group">
                <label>입학년도</label>
                <input
                  type="number"
                  required
                  value={profileForm.entry_year}
                  onChange={(e) => setProfileForm({ ...profileForm, entry_year: e.target.value })}
                />
              </div>
              <div className="form-group">
                <label>학번</label>
                <input
                  type="text"
                  required
                  value={profileForm.student_id}
                  onChange={(e) => setProfileForm({ ...profileForm, student_id: e.target.value })}
                />
              </div>
            </div>

            <div className="form-group">
              <label>새 비밀번호 (변경할 경우에만 입력 — bcrypt 재암호화 저장)</label>
              <input
                type="password"
                placeholder="기존 비밀번호를 유지하려면 비워두세요"
                value={profileForm.password}
                onChange={(e) => setProfileForm({ ...profileForm, password: e.target.value })}
              />
            </div>

            <div className="btn-group">
              <button type="submit" className="btn btn-primary">
                프로필 수정 저장
              </button>
              <button type="button" className="btn btn-danger" onClick={handleDeleteAccount}>
                회원 탈퇴
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
}

export default App;
