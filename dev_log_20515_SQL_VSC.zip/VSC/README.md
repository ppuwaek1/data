# 💻 개발 일지 & 목표 관리 웹 프로젝트 (`dev_log_20515`)

수행평가 데이터베이스 연동 프로젝트 (학번: **20515**, 이름: **이승준**)

## 📁 폴더 구성
- `dev_log_20515.sql`: MySQL 데이터베이스(`dev_log_20515`) 및 테이블 생성 SQL
- `server/`: Node.js + Express + MySQL + bcrypt + JWT 백엔드 서버 (포트 5000)
- `client/`: React + Vite 프론트엔드 웹 애플리케이션 (포트 5173)

## 🚀 실행 방법 (평가 당일 순서)

### 1. MySQL Server 실행 및 DB 세팅
- MySQL Workbench에서 `dev_log_20515.sql` 실행 (또는 백엔드 서버 실행 시 자동 생성됨)
- 실습실 MySQL 비밀번호가 `root`가 아닐 경우 `server/.env`의 `DB_PASSWORD` 수정

### 2. 백엔드 서버 (`server`) 실행
```bash
cd server
npm install
npm start
```

### 3. 프론트엔드 (`client`) 실행
```bash
cd client
npm install
npm run dev
```

## 🔑 기본 테스트 계정 (DB에 bcrypt 암호화 저장됨)
- **이승준 (20515)**: `seungjun@devlog.net` / `qazwsx1029!`
- **이동욱 (20516)**: `dongwook@devlog.net` / `qazwsx1029?`
- **이규빈 (20517)**: `kyubin@devlog.net` / `qazwsx1029.`
